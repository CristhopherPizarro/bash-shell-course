#!/bin/bash
# Programa para ejemplificar el empaquetamiento con el comando tar
# Autor: Nicolas G

echo "Empaquetar todos los scripts de la carpeta en un archivo comprimido"
tar -cvf shellCourse.tar *.sh

