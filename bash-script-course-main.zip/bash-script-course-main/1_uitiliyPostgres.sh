
# !/bin/bash
# Programa para realizar algunas operaciones utilitarias de Postgres
echo "Hola bienvenido al curso de programacion bash"
