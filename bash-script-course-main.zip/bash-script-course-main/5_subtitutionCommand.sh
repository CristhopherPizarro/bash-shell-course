# !/bin/bash
# Programa para como ejecutar comandos dentro de un programa y almacenar en una variable para su posterior utilizacion 
# Autor: Nicolas G

ubicacionActual=`pwd`
infokernel=$(uname -a)

echo "La ubicacion actual es la siguiente: $ubicacionActual"
echo "Informacion del kernel: $infokernel"








