#!/bin/bash
# Programa para ejemplificar el empaquetamiento con el comando zip
# Autor: Nicolas G

echo "Empaquetar todos los scripts de la carpeta en un archivo comprimido"
zip -e shellcourse.zip *.sh

